"""
Утилита для полной очистки клубов.

Что делает:
1. Удаляет все строки из database/Club/clubs.db (таблица clubs)
2. Удаляет все строки из database/Club/chats.db (таблица chats)
3. Сбрасывает clubID и clubRole в 0 у ВСЕХ игроков в database/Player/plr.db

Запускать из корня проекта (там же, где core.py), сервер должен быть остановлен:
    python3 reset_clubs.py
"""
import sqlite3
import os

CLUBS_DB = "database/Club/clubs.db"
CHATS_DB = "database/Club/chats.db"
PLAYERS_DB = "database/Player/plr.db"


def reset_clubs():
    if os.path.exists(CLUBS_DB):
        conn = sqlite3.connect(CLUBS_DB, timeout=30)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clubs'")
        if cur.fetchone():
            cur.execute("DELETE FROM clubs")
            conn.commit()
            print(f"[OK] Очищена таблица clubs в {CLUBS_DB}")
        conn.close()
    else:
        print(f"[skip] {CLUBS_DB} не найден")

    if os.path.exists(CHATS_DB):
        conn = sqlite3.connect(CHATS_DB, timeout=30)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='chats'")
        if cur.fetchone():
            cur.execute("DELETE FROM chats")
            conn.commit()
            print(f"[OK] Очищена таблица chats в {CHATS_DB}")
        conn.close()
    else:
        print(f"[skip] {CHATS_DB} не найден")

    if os.path.exists(PLAYERS_DB):
        conn = sqlite3.connect(PLAYERS_DB, timeout=30)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='plrs'")
        if cur.fetchone():
            cur.execute("UPDATE plrs SET clubID=0, clubRole=0")
            conn.commit()
            print(f"[OK] Сброшены clubID/clubRole у всех игроков в {PLAYERS_DB}")
        conn.close()
    else:
        print(f"[skip] {PLAYERS_DB} не найден")


if __name__ == "__main__":
    reset_clubs()
    print("Готово. Клубы очищены, у всех игроков сброшена принадлежность к клубу.")
