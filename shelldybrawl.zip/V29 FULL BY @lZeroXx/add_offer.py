"""
Добавление/удаление собственных акций (офферов) в магазине — без телеграм-бота.

Раньше это делалось через удалённого тг-бота (/new_offer). Теперь это можно
сделать прямо на сервере через консоль.

Запускать из корня проекта (там же, где core.py):
    python3 add_offer.py

Логика полностью повторяет формат Logic/offers.json, который читает
Logic/Shop.py (loadOffers/EncodeShopOffers) - см. add_offer() ниже.
"""
import json
import os

OFFERS_PATH = "Logic/offers.json"

# Значения ID (первый параметр каждого слота предложения).
# Взято из docstring Logic/Shop.py и таблицы соответствий в
# Logic/Commands/Client/LogicPurchaseOfferCommand.py.
ITEM_IDS = {
    0: "Free Brawl Box",
    1: "Gold",
    2: "Random Brawler",
    3: "Brawler",
    4: "Skin",
    5: "StarPower/Gadget",
    6: "Brawl Box",
    7: "Tickets (не работает)",
    8: "Power Points (для конкретного бойца)",
    9: "Token Doubler",
    10: "Mega Box",
    11: "Keys (???)",
    12: "Power Points",
    13: "EventSlot (???)",
    14: "Big Box",
    15: "AdBox (не работает)",
    16: "Gems",
    19: "Pin for Brawler",
    20: "Pin Collection",
    21: "Pin Pack",
    22: "Pins Pack For Brawler",
    23: "Pin Common (???)",
    24: "Shop Skin Offer (может не работать)",
}

SHOP_TYPES = {
    0: "Gems (валюта - гемы)",
    1: "Gold (валюта - золото)",
}

OFFER_BGR = [
    "offer_generic", "offer_special", "offer_legendary", "offer_coins",
    "offer_moon_festival", "offer_gems", "offer_boxes", "offer_finals",
    "offer_lny", "offer_archive", "offer_chromatic", "offer_xmas",
]


def load_offers():
    if not os.path.exists(OFFERS_PATH):
        return {}
    with open(OFFERS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_offers(data):
    with open(OFFERS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def print_legend():
    print("\n=== ID предмета (Item ID) ===")
    for k, v in ITEM_IDS.items():
        print(f"  {k:>3} = {v}")
    print("\n=== ShopType (валюта покупки) ===")
    for k, v in SHOP_TYPES.items():
        print(f"  {k} = {v}")
    print("\n=== Варианты OfferBGR (фон/тема оффера) ===")
    for v in OFFER_BGR:
        print(f"  {v}")
    print()


def ask_int(prompt, default=0):
    raw = input(f"{prompt} [{default}]: ").strip()
    return int(raw) if raw else default


def ask_str(prompt, default=""):
    raw = input(f"{prompt} [{default}]: ").strip()
    return raw if raw else default


def add_offer():
    data = load_offers()
    next_id = str(max([int(k) for k in data.keys()], default=-1) + 1)

    print(f"\nСоздание новой акции (offer #{next_id})")
    print_legend()

    title = ask_str("OfferTitle (внутреннее имя)", "custom_offer")
    cost = ask_int("Cost (стоимость)", 100)
    old_cost = ask_int("OldCost (0, если без старой цены)", 0)
    shop_type = ask_int("ShopType (0=гемы, 1=золото)", 0)
    shop_display = ask_int("ShopDisplay (0=обычный, 1=акция дня)", 0)
    bgr = ask_str("OfferBGR (см. список выше)", "offer_generic")
    timer = ask_int("Timer, сек. (86400 = 24ч)", 86400)

    item_id = ask_int("ID предмета в 1-м слоте (см. легенду выше)", 1)
    multiplier = ask_int("Количество (Multiplier) для 1-го слота", 1)
    brawler_id = ask_int("BrawlerID для 1-го слота (0, если не нужен)", 0)
    skin_id = ask_int("SkinID для 1-го слота (0, если не нужен)", 0)

    new_offer = {
        "ID": [item_id, 0, 0],
        "OfferTitle": title,
        "Cost": cost,
        "OldCost": old_cost,
        "Multiplier": [multiplier, 0, 0],
        "BrawlerID": [brawler_id, 0, 0],
        "SkinID": [skin_id, 0, 0],
        "WhoBuyed": [],
        "Timer": timer,
        "OfferBGR": bgr,
        "ShopType": shop_type,
        "ShopDisplay": shop_display,
    }

    data[next_id] = new_offer
    save_offers(data)
    print(f"\n[OK] Акция #{next_id} добавлена в {OFFERS_PATH}")


def remove_offer():
    data = load_offers()
    if not data:
        print("Акций нет.")
        return
    print("\nТекущие акции:")
    for k, v in data.items():
        print(f"  #{k}: {v.get('OfferTitle')} (ID={v.get('ID')}, Cost={v.get('Cost')})")
    idx = ask_str("Какую акцию удалить (номер)?", "")
    if idx in data:
        data.pop(idx)
        save_offers(data)
        print(f"[OK] Акция #{idx} удалена.")
    else:
        print("Такой акции нет.")


if __name__ == "__main__":
    print("1) Добавить акцию")
    print("2) Удалить акцию")
    print("3) Показать легенду ID")
    choice = input("Выбор: ").strip()
    if choice == "1":
        add_offer()
    elif choice == "2":
        remove_offer()
    else:
        print_legend()
