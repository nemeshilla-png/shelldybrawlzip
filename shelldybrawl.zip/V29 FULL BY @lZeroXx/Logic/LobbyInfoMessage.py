from Utils.Writer import Writer
from datetime import datetime
import random
class LobbyInfoMessage(Writer):
    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count

    def encode(self):
        now = datetime.now()
        ping = random.randint(19,33)
        self.writeVint(0)#\nPlayer Online: {self.count}
        self.writeString(f'<c2E2E2E>V</c><c4A4A4A>2</c><c666666>9</c> <c828282>F</c><c9E9E9E>U</c><cBABABA>L</c><cD6D6D6>L</c>')
        self.writeVint(0)