from Utils.Reader import BSMessageReader
from database.DataBase import DataBase
from Server.Club.MyAllianceMessage import MyAllianceMessage
from Server.Club.AllianceChatServer import AllianceChatServer
from Server.Club.KickMemberOK import AllianceKickMemberOK


class Kick_Member_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
    def decode(self):
        self.read_int()
        self.lowID = self.read_int()
        self.reason = self.read_string()
    def process(self):
        account = DataBase.loadbyID(self, self.lowID)
        # plrs columns: 0 token, 1 lowID, 2 name, 3 trophies, ... 11 clubID, 12 clubRole
        # account[3] is trophies and account[1] is the lowID, not the clubID/name -
        # using them as such made kicking use the wrong club and store the wrong name.
        DataBase.AddMember(self, account[11], self.lowID, account[2], 2)
        AllianceKickMemberOK(self.client, self.player).send()
        self.clubLowID = account[11]
        i = DataBase.loadbyID(self, self.player.low_id)
        
        DataBase.replaceOtherValue(self, self.lowID, "clubID", 0)
        DataBase.replaceOtherValue(self, self.lowID, "clubRole", 0)
        DataBase.Addmsg(self, self.player.club_low_id, 4, 1, account[1], self.player.name, self.player.club_role, 1)
        
        	
        MyAllianceMessage(self.client, self.player, self.clubLowID).send()
        DataBase.loadClub(self, self.player.club_low_id)
        for i in self.plrids:
        	AllianceChatServer(self.client, self.player, "dev", self.player.club_low_id).send()